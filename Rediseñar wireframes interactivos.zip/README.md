
  # Rediseñar wireframes interactivos

  This is a code bundle for Rediseñar wireframes interactivos. The original project is available at https://www.figma.com/design/0rLL2TzVaIxPDC1MypIjfT/Redise%C3%B1ar-wireframes-interactivos.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  